"""This file contains the Identity class."""

import cipher.Identity


class Identity(cipher.Identity.Identity): 

    """There is no GUI, so this class is trivial."""

    pass
