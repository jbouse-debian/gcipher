from Rot import Rot
class Ceasar(Rot):
    def __init__(self): 
        self.key = 3
