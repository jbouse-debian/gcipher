import cipher.Ceasar
class Ceasar(cipher.Ceasar.Ceasar): pass
