import cipher.Gie
class Gie(cipher.Gie.Gie): pass
